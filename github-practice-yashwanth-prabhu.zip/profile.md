# Personal Profile

## Name
Yashwanth Prabhu

## Interests
- Learning Java and Data Structures
- Exploring Git and GitHub workflows
- Technology and problem solving

## What I Hope to Learn From This Course
I want to understand real-world GitHub collaboration, pull request workflows,
and best practices used in professional software development teams.

## Fun Fact
I enjoy breaking down complex problems into simple logic and examples.
