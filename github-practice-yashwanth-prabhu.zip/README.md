# GitHub Practice Repository

This repository is created to practice GitHub workflows such as branching,
committing, and creating pull requests.
